import os
from dotenv import load_dotenv
from pathlib import Path

# Carrega variáveis de ambiente do arquivo .env
env_path = Path(__file__).resolve().parent.parent.parent / '.env'
load_dotenv(dotenv_path=env_path)

class Settings:
    PROJECT_NAME: str = "Sistema Financeiro"
    PROJECT_VERSION: str = "0.1.0"
    
    # Configurações do banco de dados
    DATABASE_URL: str = os.getenv("DATABASE_URL")
    
    # Configurações de segurança
    SECRET_KEY: str = os.getenv("SECRET_KEY", "chave_secreta_temporaria")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 dias
    
    # CORS
    BACKEND_CORS_ORIGINS: list = ["*"]

settings = Settings()
