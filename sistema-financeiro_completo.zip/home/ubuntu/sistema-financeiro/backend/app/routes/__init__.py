from fastapi import APIRouter

from routes import contas_receber, contas_pagar

router = APIRouter()
router.include_router(contas_receber.router)
router.include_router(contas_pagar.router)
