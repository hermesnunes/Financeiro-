from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date

from core.database import get_db
from core.dependencies import get_current_active_user
from schemas.schemas import ContaPagar, ContaPagarCreate, ContaPagarUpdate, User
from crud.contas_pagar import (
    get_contas_pagar,
    get_conta_pagar,
    create_conta_pagar,
    update_conta_pagar,
    delete_conta_pagar
)

router = APIRouter(
    prefix="/api/contas-pagar",
    tags=["contas-pagar"],
    dependencies=[Depends(get_current_active_user)], # Protege todas as rotas neste router
    responses={404: {"description": "Não encontrado"}},
)

@router.get("/", response_model=List[ContaPagar])
def read_contas_pagar(
    skip: int = 0, 
    limit: int = 100, 
    status: Optional[str] = None,
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user) # Obtém o usuário atual
):
    """
    Retorna a lista de contas a pagar com opções de filtro por status e período.
    (Apenas contas do usuário autenticado, se a lógica multi-usuário for implementada no CRUD)
    """
    # TODO: Modificar get_contas_pagar para filtrar por current_user.id se for multi-usuário
    contas = get_contas_pagar(db, skip=skip, limit=limit, status=status, data_inicio=data_inicio, data_fim=data_fim)
    return contas

@router.get("/{conta_id}", response_model=ContaPagar)
def read_conta_pagar(conta_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    """
    Retorna uma conta a pagar específica pelo ID.
    (Verificar permissão do usuário se multi-usuário)
    """
    db_conta = get_conta_pagar(db, conta_id=conta_id)
    if db_conta is None:
        raise HTTPException(status_code=404, detail="Conta a pagar não encontrada")
    # TODO: Adicionar verificação se db_conta.owner_id == current_user.id se for multi-usuário
    return db_conta

@router.post("/", response_model=ContaPagar, status_code=status.HTTP_201_CREATED)
def create_conta_pagar_route(conta: ContaPagarCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    """
    Cria uma nova conta a pagar.
    (Associar ao usuário atual se multi-usuário)
    """
    # TODO: Modificar create_conta_pagar para aceitar owner_id=current_user.id se for multi-usuário
    return create_conta_pagar(db=db, conta=conta)

@router.put("/{conta_id}", response_model=ContaPagar)
def update_conta_pagar_route(conta_id: int, conta: ContaPagarUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    """
    Atualiza uma conta a pagar existente.
    (Verificar permissão do usuário se multi-usuário)
    """
    db_conta = get_conta_pagar(db, conta_id=conta_id)
    if db_conta is None:
        raise HTTPException(status_code=404, detail="Conta a pagar não encontrada")
    # TODO: Adicionar verificação se db_conta.owner_id == current_user.id se for multi-usuário
    return update_conta_pagar(db=db, conta_id=conta_id, conta=conta)

@router.delete("/{conta_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_conta_pagar_route(conta_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    """
    Remove uma conta a pagar.
    (Verificar permissão do usuário se multi-usuário)
    """
    db_conta = get_conta_pagar(db, conta_id=conta_id)
    if db_conta is None:
        raise HTTPException(status_code=404, detail="Conta a pagar não encontrada")
    # TODO: Adicionar verificação se db_conta.owner_id == current_user.id se for multi-usuário
    delete_conta_pagar(db=db, conta_id=conta_id)
    # Retornar JSONResponse em vez de nada para evitar erro no FastAPI < 0.70.0
    from fastapi.responses import JSONResponse
    return JSONResponse(status_code=status.HTTP_204_NO_CONTENT)
