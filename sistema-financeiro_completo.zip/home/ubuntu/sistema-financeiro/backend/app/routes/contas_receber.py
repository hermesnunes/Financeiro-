from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date

from core.database import get_db
from core.dependencies import get_current_active_user
from schemas.schemas import ContaReceber, ContaReceberCreate, ContaReceberUpdate, User
from crud.contas_receber import (
    get_contas_receber,
    get_conta_receber,
    create_conta_receber,
    update_conta_receber,
    delete_conta_receber
)

router = APIRouter(
    prefix="/api/contas-receber",
    tags=["contas-receber"],
    dependencies=[Depends(get_current_active_user)], # Protege todas as rotas neste router
    responses={404: {"description": "Não encontrado"}},
)

@router.get("/", response_model=List[ContaReceber])
def read_contas_receber(
    skip: int = 0, 
    limit: int = 100, 
    status: Optional[str] = None,
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user) # Obtém o usuário atual
):
    """
    Retorna a lista de contas a receber com opções de filtro por status e período.
    (Apenas contas do usuário autenticado, se a lógica multi-usuário for implementada no CRUD)
    """
    # TODO: Modificar get_contas_receber para filtrar por current_user.id se for multi-usuário
    contas = get_contas_receber(db, skip=skip, limit=limit, status=status, data_inicio=data_inicio, data_fim=data_fim)
    return contas

@router.get("/{conta_id}", response_model=ContaReceber)
def read_conta_receber(conta_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    """
    Retorna uma conta a receber específica pelo ID.
    (Verificar permissão do usuário se multi-usuário)
    """
    db_conta = get_conta_receber(db, conta_id=conta_id)
    if db_conta is None:
        raise HTTPException(status_code=404, detail="Conta a receber não encontrada")
    # TODO: Adicionar verificação se db_conta.owner_id == current_user.id se for multi-usuário
    return db_conta

@router.post("/", response_model=ContaReceber, status_code=status.HTTP_201_CREATED)
def create_conta_receber_route(conta: ContaReceberCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    """
    Cria uma nova conta a receber.
    (Associar ao usuário atual se multi-usuário)
    """
    # TODO: Modificar create_conta_receber para aceitar owner_id=current_user.id se for multi-usuário
    return create_conta_receber(db=db, conta=conta)

@router.put("/{conta_id}", response_model=ContaReceber)
def update_conta_receber_route(conta_id: int, conta: ContaReceberUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    """
    Atualiza uma conta a receber existente.
    (Verificar permissão do usuário se multi-usuário)
    """
    db_conta = get_conta_receber(db, conta_id=conta_id)
    if db_conta is None:
        raise HTTPException(status_code=404, detail="Conta a receber não encontrada")
    # TODO: Adicionar verificação se db_conta.owner_id == current_user.id se for multi-usuário
    return update_conta_receber(db=db, conta_id=conta_id, conta=conta)

@router.delete("/{conta_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_conta_receber_route(conta_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    """
    Remove uma conta a receber.
    (Verificar permissão do usuário se multi-usuário)
    """
    db_conta = get_conta_receber(db, conta_id=conta_id)
    if db_conta is None:
        raise HTTPException(status_code=404, detail="Conta a receber não encontrada")
    # TODO: Adicionar verificação se db_conta.owner_id == current_user.id se for multi-usuário
    delete_conta_receber(db=db, conta_id=conta_id)
    # Retornar JSONResponse em vez de nada para evitar erro no FastAPI < 0.70.0
    from fastapi.responses import JSONResponse
    return JSONResponse(status_code=status.HTTP_204_NO_CONTENT)
