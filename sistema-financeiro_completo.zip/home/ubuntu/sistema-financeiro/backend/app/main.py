from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from core.config import settings
from core.database import engine, Base
from routes import contas_receber, contas_pagar, auth # Importar o novo router de autenticação

# Cria as tabelas no banco de dados (incluindo a tabela User)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.PROJECT_VERSION
)

# Configuração de CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir rotas
app.include_router(auth.router) # Incluir rotas de autenticação
app.include_router(contas_receber.router)
app.include_router(contas_pagar.router)

@app.get("/")
def read_root():
    return {"message": "Bem-vindo ao Sistema Financeiro API"}

@app.get("/api/health")
def health_check():
    return JSONResponse(content={"status": "ok"}, status_code=200)
