from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import Optional, List
from datetime import date

from models.models import ContaPagar, StatusPagamento
from schemas.schemas import ContaPagarCreate, ContaPagarUpdate

def get_conta_pagar(db: Session, conta_id: int):
    return db.query(ContaPagar).filter(ContaPagar.id == conta_id).first()

def get_contas_pagar(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    status: Optional[str] = None,
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None
) -> List[ContaPagar]:
    query = db.query(ContaPagar)
    
    filters = []
    if status:
        try:
            status_enum = StatusPagamento(status.lower())
            filters.append(ContaPagar.status == status_enum)
        except ValueError:
            # Ignora status inválido ou retorna erro
            pass
            
    if data_inicio:
        filters.append(ContaPagar.data_vencimento >= data_inicio)
        
    if data_fim:
        filters.append(ContaPagar.data_vencimento <= data_fim)
        
    if filters:
        query = query.filter(and_(*filters))
        
    return query.offset(skip).limit(limit).all()

def create_conta_pagar(db: Session, conta: ContaPagarCreate) -> ContaPagar:
    db_conta = ContaPagar(**conta.dict())
    db.add(db_conta)
    db.commit()
    db.refresh(db_conta)
    return db_conta

def update_conta_pagar(db: Session, conta_id: int, conta: ContaPagarUpdate) -> Optional[ContaPagar]:
    db_conta = get_conta_pagar(db, conta_id)
    if db_conta:
        update_data = conta.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_conta, key, value)
        db.commit()
        db.refresh(db_conta)
    return db_conta

def delete_conta_pagar(db: Session, conta_id: int) -> Optional[ContaPagar]:
    db_conta = get_conta_pagar(db, conta_id)
    if db_conta:
        db.delete(db_conta)
        db.commit()
    return db_conta
