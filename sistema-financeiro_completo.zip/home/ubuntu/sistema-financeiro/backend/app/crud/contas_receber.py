from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import Optional, List
from datetime import date

from models.models import ContaReceber, StatusRecebimento
from schemas.schemas import ContaReceberCreate, ContaReceberUpdate

def get_conta_receber(db: Session, conta_id: int):
    return db.query(ContaReceber).filter(ContaReceber.id == conta_id).first()

def get_contas_receber(
    db: Session, 
    skip: int = 0, 
    limit: int = 100, 
    status: Optional[str] = None,
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None
) -> List[ContaReceber]:
    query = db.query(ContaReceber)
    
    filters = []
    if status:
        try:
            status_enum = StatusRecebimento(status.lower())
            filters.append(ContaReceber.status == status_enum)
        except ValueError:
            # Ignora status inválido ou retorna erro, dependendo da preferência
            pass 
            
    if data_inicio:
        filters.append(ContaReceber.data_prevista >= data_inicio)
        
    if data_fim:
        filters.append(ContaReceber.data_prevista <= data_fim)
        
    if filters:
        query = query.filter(and_(*filters))
        
    return query.offset(skip).limit(limit).all()

def create_conta_receber(db: Session, conta: ContaReceberCreate) -> ContaReceber:
    db_conta = ContaReceber(**conta.dict())
    db.add(db_conta)
    db.commit()
    db.refresh(db_conta)
    return db_conta

def update_conta_receber(db: Session, conta_id: int, conta: ContaReceberUpdate) -> Optional[ContaReceber]:
    db_conta = get_conta_receber(db, conta_id)
    if db_conta:
        update_data = conta.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_conta, key, value)
        db.commit()
        db.refresh(db_conta)
    return db_conta

def delete_conta_receber(db: Session, conta_id: int) -> Optional[ContaReceber]:
    db_conta = get_conta_receber(db, conta_id)
    if db_conta:
        db.delete(db_conta)
        db.commit()
    return db_conta
