from datetime import datetime, date
from typing import Optional, List
from sqlalchemy import Column, Integer, String, Float, Date, DateTime, ForeignKey, Enum, Text, Boolean
from sqlalchemy.orm import relationship
import enum

from core.database import Base

# --- Enums --- 
class StatusPagamento(str, enum.Enum):
    PENDENTE = "pendente"
    PAGO = "pago"
    ATRASADO = "atrasado"

class StatusRecebimento(str, enum.Enum):
    PENDENTE = "pendente"
    RECEBIDO = "recebido"
    ATRASADO = "atrasado"

class MeioPagamento(str, enum.Enum):
    PIX = "pix"
    BOLETO = "boleto"
    CARTAO = "cartao"
    DINHEIRO = "dinheiro"
    TRANSFERENCIA = "transferencia"

# --- Models --- 
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=True)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
    data_criacao = Column(DateTime, default=datetime.utcnow)

class ContaReceber(Base):
    __tablename__ = "contas_receber"
    
    id = Column(Integer, primary_key=True, index=True)
    valor = Column(Float, nullable=False)
    data_prevista = Column(Date, nullable=False)
    data_recebimento = Column(Date, nullable=True)
    origem = Column(String(100), nullable=False)
    cliente = Column(String(100), nullable=False)
    descricao = Column(Text, nullable=True)
    meio_pagamento = Column(Enum(MeioPagamento), nullable=False)
    conta_recebimento = Column(String(100), nullable=True)
    status = Column(Enum(StatusRecebimento), default=StatusRecebimento.PENDENTE, nullable=False)
    comprovante = Column(String(255), nullable=True)
    data_criacao = Column(DateTime, default=datetime.utcnow)
    data_atualizacao = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    # owner_id = Column(Integer, ForeignKey("users.id")) # Add if needed for multi-user
    # owner = relationship("User")

class ContaPagar(Base):
    __tablename__ = "contas_pagar"
    
    id = Column(Integer, primary_key=True, index=True)
    valor = Column(Float, nullable=False)
    data_vencimento = Column(Date, nullable=False)
    data_pagamento = Column(Date, nullable=True)
    destino = Column(String(100), nullable=False)
    descricao = Column(Text, nullable=True)
    meio_pagamento = Column(Enum(MeioPagamento), nullable=False)
    conta_pagamento = Column(String(100), nullable=True)
    status = Column(Enum(StatusPagamento), default=StatusPagamento.PENDENTE, nullable=False)
    comprovante = Column(String(255), nullable=True)
    data_criacao = Column(DateTime, default=datetime.utcnow)
    data_atualizacao = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    # owner_id = Column(Integer, ForeignKey("users.id")) # Add if needed for multi-user
    # owner = relationship("User")

class Funcionario(Base):
    __tablename__ = "funcionarios"
    
    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String(100), nullable=False)
    cargo = Column(String(100), nullable=True)
    salario = Column(Float, nullable=False)
    data_pagamento = Column(Integer, nullable=False)  # Dia do mês para pagamento
    ativo = Column(Boolean, default=True)
    data_criacao = Column(DateTime, default=datetime.utcnow)
    data_atualizacao = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Imposto(Base):
    __tablename__ = "impostos"
    
    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String(100), nullable=False)
    valor = Column(Float, nullable=False)
    data_vencimento = Column(Date, nullable=False)
    data_pagamento = Column(Date, nullable=True)
    cnpj_cpf = Column(String(20), nullable=True)
    status = Column(Enum(StatusPagamento), default=StatusPagamento.PENDENTE, nullable=False)
    data_criacao = Column(DateTime, default=datetime.utcnow)
    data_atualizacao = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
