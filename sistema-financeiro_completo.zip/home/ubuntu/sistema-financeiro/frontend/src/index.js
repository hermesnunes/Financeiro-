import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

// Configuração do tema Material UI (opcional, pode personalizar)
const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2', // Azul
    },
    secondary: {
      main: '#dc004e', // Rosa
    },
    background: {
      default: '#f4f6f8', // Cinza claro para o fundo
      paper: '#ffffff', // Branco para cards e papers
    },
  },
});

// Definir a URL base da API
// Em desenvolvimento, pode ser 'http://localhost:8000/api'
// Em produção, será a URL do backend implantado (ex: 'https://sistema-financeiro-backend.onrender.com/api')
// Usar variável de ambiente é a melhor prática
export const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8000/api';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <App />
    </ThemeProvider>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
