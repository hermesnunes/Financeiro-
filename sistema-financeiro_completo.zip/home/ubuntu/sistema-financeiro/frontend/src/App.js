import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import axios from 'axios';

import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import ContasReceber from './pages/ContasReceber';
import ContasPagar from './pages/ContasPagar';
import Configuracoes from './pages/Configuracoes';
import LoginPage from './pages/Login';
import RegisterPage from './pages/Register';

// Componente para rotas protegidas
const ProtectedRoute = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(null); // null = loading, true = authenticated, false = not authenticated

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      // Aqui você pode adicionar uma verificação de token no backend se desejar
      // Por simplicidade, vamos apenas verificar se o token existe
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      setIsAuthenticated(true);
    } else {
      setIsAuthenticated(false);
    }
  }, []);

  if (isAuthenticated === null) {
    return <div>Carregando...</div>; // Ou um spinner de carregamento
  }

  return isAuthenticated ? <Outlet /> : <Navigate to="/login" replace />;
};

// Componente para rotas públicas (Login, Registro)
const PublicRoute = () => {
  const isAuthenticated = !!localStorage.getItem('accessToken');
  return !isAuthenticated ? <Outlet /> : <Navigate to="/" replace />;
};

function App() {
  return (
    <Router>
      <Routes>
        {/* Rotas Públicas (Login, Registro) */}
        <Route element={<PublicRoute />}>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
        </Route>

        {/* Rotas Protegidas (dentro do Layout) */}
        <Route element={<ProtectedRoute />}>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="contas-receber" element={<ContasReceber />} />
            <Route path="contas-pagar" element={<ContasPagar />} />
            <Route path="configuracoes" element={<Configuracoes />} />
            {/* Adicione outras rotas protegidas aqui */}
          </Route>
        </Route>

        {/* Rota para lidar com caminhos não encontrados */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
