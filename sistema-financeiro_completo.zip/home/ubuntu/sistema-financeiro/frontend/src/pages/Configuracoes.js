import React, { useState } from 'react';
import { 
  Typography, 
  Paper, 
  Grid, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Alert,
  Snackbar,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  Box
} from '@mui/material';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import NotificationsIcon from '@mui/icons-material/Notifications';
import axios from 'axios';

const API_URL = 'http://localhost:8000/api';

const Configuracoes = () => {
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [openExportDialog, setOpenExportDialog] = useState(false);
  const [openAlertasDialog, setOpenAlertasDialog] = useState(false);
  const [exportConfig, setExportConfig] = useState({
    tipo: 'contas_receber',
    formato: 'csv',
    periodo: 'mes_atual'
  });
  const [alertasConfig, setAlertasConfig] = useState({
    dias_antecedencia: 3,
    notificar_vencimentos: true,
    notificar_recebimentos: true,
    notificar_atrasos: true
  });

  const handleExportConfigChange = (e) => {
    const { name, value } = e.target;
    setExportConfig({
      ...exportConfig,
      [name]: value
    });
  };

  const handleAlertasConfigChange = (e) => {
    const { name, value, checked, type } = e.target;
    setAlertasConfig({
      ...alertasConfig,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleExportar = () => {
    // Simulação de exportação
    setTimeout(() => {
      setOpenExportDialog(false);
      setSnackbarMessage(`Dados exportados com sucesso no formato ${exportConfig.formato.toUpperCase()}`);
      setOpenSnackbar(true);
    }, 1000);
  };

  const handleSalvarAlertas = () => {
    // Simulação de salvamento de configurações de alertas
    setTimeout(() => {
      setOpenAlertasDialog(false);
      setSnackbarMessage('Configurações de alertas salvas com sucesso');
      setOpenSnackbar(true);
    }, 1000);
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <>
      <Typography variant="h5" component="h1" gutterBottom>
        Configurações e Recursos Adicionais
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Exportação de Dados
            </Typography>
            <Typography variant="body1" paragraph>
              Exporte seus dados financeiros para análise em outras ferramentas ou para backup.
            </Typography>
            <Button 
              variant="contained" 
              startIcon={<FileDownloadIcon />}
              onClick={() => setOpenExportDialog(true)}
            >
              Exportar Dados
            </Button>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Configuração de Alertas
            </Typography>
            <Typography variant="body1" paragraph>
              Configure alertas para vencimentos, recebimentos e atrasos.
            </Typography>
            <Button 
              variant="contained" 
              startIcon={<NotificationsIcon />}
              onClick={() => setOpenAlertasDialog(true)}
            >
              Configurar Alertas
            </Button>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Lançamentos Recorrentes
            </Typography>
            <Typography variant="body1" paragraph>
              Configure lançamentos que se repetem automaticamente todos os meses, como aluguel, salários e assinaturas.
            </Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Descrição</TableCell>
                    <TableCell>Tipo</TableCell>
                    <TableCell>Valor</TableCell>
                    <TableCell>Dia do Mês</TableCell>
                    <TableCell>Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell colSpan={5} align="center">
                      Nenhum lançamento recorrente configurado
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
            <Box sx={{ mt: 2 }}>
              <Button variant="contained" color="primary">
                Adicionar Lançamento Recorrente
              </Button>
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Diálogo de Exportação */}
      <Dialog open={openExportDialog} onClose={() => setOpenExportDialog(false)}>
        <DialogTitle>Exportar Dados</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Tipo de Dados</InputLabel>
                <Select
                  name="tipo"
                  value={exportConfig.tipo}
                  onChange={handleExportConfigChange}
                  label="Tipo de Dados"
                >
                  <MenuItem value="contas_receber">Contas a Receber</MenuItem>
                  <MenuItem value="contas_pagar">Contas a Pagar</MenuItem>
                  <MenuItem value="fluxo_caixa">Fluxo de Caixa</MenuItem>
                  <MenuItem value="todos">Todos os Dados</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Formato</InputLabel>
                <Select
                  name="formato"
                  value={exportConfig.formato}
                  onChange={handleExportConfigChange}
                  label="Formato"
                >
                  <MenuItem value="csv">CSV</MenuItem>
                  <MenuItem value="excel">Excel</MenuItem>
                  <MenuItem value="pdf">PDF</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Período</InputLabel>
                <Select
                  name="periodo"
                  value={exportConfig.periodo}
                  onChange={handleExportConfigChange}
                  label="Período"
                >
                  <MenuItem value="mes_atual">Mês Atual</MenuItem>
                  <MenuItem value="mes_anterior">Mês Anterior</MenuItem>
                  <MenuItem value="trimestre">Último Trimestre</MenuItem>
                  <MenuItem value="ano">Ano Atual</MenuItem>
                  <MenuItem value="todos">Todos os Períodos</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenExportDialog(false)}>Cancelar</Button>
          <Button onClick={handleExportar} variant="contained" color="primary">
            Exportar
          </Button>
        </DialogActions>
      </Dialog>

      {/* Diálogo de Alertas */}
      <Dialog open={openAlertasDialog} onClose={() => setOpenAlertasDialog(false)}>
        <DialogTitle>Configurar Alertas</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                name="dias_antecedencia"
                label="Dias de Antecedência para Alertas"
                type="number"
                fullWidth
                value={alertasConfig.dias_antecedencia}
                onChange={handleAlertasConfigChange}
                helperText="Quantos dias antes do vencimento você deseja ser alertado"
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Notificar Vencimentos</InputLabel>
                <Select
                  name="notificar_vencimentos"
                  value={alertasConfig.notificar_vencimentos}
                  onChange={handleAlertasConfigChange}
                  label="Notificar Vencimentos"
                >
                  <MenuItem value={true}>Sim</MenuItem>
                  <MenuItem value={false}>Não</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Notificar Recebimentos</InputLabel>
                <Select
                  name="notificar_recebimentos"
                  value={alertasConfig.notificar_recebimentos}
                  onChange={handleAlertasConfigChange}
                  label="Notificar Recebimentos"
                >
                  <MenuItem value={true}>Sim</MenuItem>
                  <MenuItem value={false}>Não</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Notificar Atrasos</InputLabel>
                <Select
                  name="notificar_atrasos"
                  value={alertasConfig.notificar_atrasos}
                  onChange={handleAlertasConfigChange}
                  label="Notificar Atrasos"
                >
                  <MenuItem value={true}>Sim</MenuItem>
                  <MenuItem value={false}>Não</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenAlertasDialog(false)}>Cancelar</Button>
          <Button onClick={handleSalvarAlertas} variant="contained" color="primary">
            Salvar
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar para mensagens */}
      <Snackbar
        open={openSnackbar}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseSnackbar} severity="success" sx={{ width: '100%' }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </>
  );
};

export default Configuracoes;
