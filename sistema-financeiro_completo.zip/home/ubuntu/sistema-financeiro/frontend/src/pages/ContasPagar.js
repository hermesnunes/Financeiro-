import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Grid, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  TablePagination,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  Box
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import axios from 'axios';
import ptBR from 'date-fns/locale/pt-BR';

const API_URL = 'http://localhost:8000/api';

const ContasPagar = () => {
  const [contas, setContas] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [openDialog, setOpenDialog] = useState(false);
  const [currentConta, setCurrentConta] = useState(null);
  const [formData, setFormData] = useState({
    valor: '',
    data_vencimento: null,
    destino: '',
    descricao: '',
    meio_pagamento: '',
    conta_pagamento: '',
    status: 'pendente'
  });

  useEffect(() => {
    fetchContas();
  }, []);

  const fetchContas = async () => {
    try {
      const response = await axios.get(`${API_URL}/contas-pagar/`);
      setContas(response.data);
    } catch (error) {
      console.error('Erro ao buscar contas a pagar:', error);
    }
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleOpenDialog = (conta = null) => {
    if (conta) {
      setCurrentConta(conta);
      setFormData({
        valor: conta.valor,
        data_vencimento: new Date(conta.data_vencimento),
        destino: conta.destino,
        descricao: conta.descricao || '',
        meio_pagamento: conta.meio_pagamento,
        conta_pagamento: conta.conta_pagamento || '',
        status: conta.status
      });
    } else {
      setCurrentConta(null);
      setFormData({
        valor: '',
        data_vencimento: null,
        destino: '',
        descricao: '',
        meio_pagamento: '',
        conta_pagamento: '',
        status: 'pendente'
      });
    }
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleDateChange = (date) => {
    setFormData({
      ...formData,
      data_vencimento: date
    });
  };

  const handleSubmit = async () => {
    try {
      const data = {
        ...formData,
        data_vencimento: formData.data_vencimento.toISOString().split('T')[0]
      };

      if (currentConta) {
        await axios.put(`${API_URL}/contas-pagar/${currentConta.id}`, data);
      } else {
        await axios.post(`${API_URL}/contas-pagar/`, data);
      }
      
      fetchContas();
      handleCloseDialog();
    } catch (error) {
      console.error('Erro ao salvar conta a pagar:', error);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir esta conta a pagar?')) {
      try {
        await axios.delete(`${API_URL}/contas-pagar/${id}`);
        fetchContas();
      } catch (error) {
        console.error('Erro ao excluir conta a pagar:', error);
      }
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pago':
        return 'success';
      case 'pendente':
        return 'warning';
      case 'atrasado':
        return 'error';
      default:
        return 'default';
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
  };

  return (
    <>
      <Grid container spacing={3} alignItems="center" sx={{ mb: 3 }}>
        <Grid item xs>
          <Typography variant="h5" component="h1">
            Contas a Pagar
          </Typography>
        </Grid>
        <Grid item>
          <Button 
            variant="contained" 
            color="primary" 
            startIcon={<AddIcon />}
            onClick={() => handleOpenDialog()}
          >
            Nova Conta
          </Button>
        </Grid>
      </Grid>

      <Paper sx={{ width: '100%', overflow: 'hidden' }}>
        <TableContainer sx={{ maxHeight: 440 }}>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                <TableCell>Destino</TableCell>
                <TableCell>Valor</TableCell>
                <TableCell>Data Vencimento</TableCell>
                <TableCell>Data Pagamento</TableCell>
                <TableCell>Meio de Pagamento</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="center">Ações</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {contas
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((conta) => (
                  <TableRow hover key={conta.id}>
                    <TableCell>{conta.destino}</TableCell>
                    <TableCell>{formatCurrency(conta.valor)}</TableCell>
                    <TableCell>{formatDate(conta.data_vencimento)}</TableCell>
                    <TableCell>{formatDate(conta.data_pagamento)}</TableCell>
                    <TableCell>{conta.meio_pagamento}</TableCell>
                    <TableCell>
                      <Chip 
                        label={conta.status} 
                        color={getStatusColor(conta.status)} 
                        size="small" 
                      />
                    </TableCell>
                    <TableCell align="center">
                      <IconButton 
                        size="small" 
                        color="primary"
                        onClick={() => handleOpenDialog(conta)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton 
                        size="small" 
                        color="error"
                        onClick={() => handleDelete(conta.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              {contas.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} align="center">
                    Nenhuma conta a pagar encontrada
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[10, 25, 100]}
          component="div"
          count={contas.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          labelRowsPerPage="Linhas por página:"
          labelDisplayedRows={({ from, to, count }) => `${from}-${to} de ${count}`}
        />
      </Paper>

      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>
          {currentConta ? 'Editar Conta a Pagar' : 'Nova Conta a Pagar'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <TextField
                name="destino"
                label="Destino"
                fullWidth
                value={formData.destino}
                onChange={handleInputChange}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="valor"
                label="Valor"
                type="number"
                fullWidth
                value={formData.valor}
                onChange={handleInputChange}
                InputProps={{
                  startAdornment: 'R$',
                }}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={ptBR}>
                <DatePicker
                  label="Data Vencimento"
                  value={formData.data_vencimento}
                  onChange={handleDateChange}
                  renderInput={(params) => <TextField {...params} fullWidth required />}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth required>
                <InputLabel id="meio-pagamento-label">Meio de Pagamento</InputLabel>
                <Select
                  labelId="meio-pagamento-label"
                  name="meio_pagamento"
                  value={formData.meio_pagamento}
                  onChange={handleInputChange}
                  label="Meio de Pagamento"
                >
                  <MenuItem value="pix">PIX</MenuItem>
                  <MenuItem value="boleto">Boleto</MenuItem>
                  <MenuItem value="cartao">Cartão</MenuItem>
                  <MenuItem value="dinheiro">Dinheiro</MenuItem>
                  <MenuItem value="transferencia">Transferência</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth required>
                <InputLabel id="status-label">Status</InputLabel>
                <Select
                  labelId="status-label"
                  name="status"
                  value={formData.status}
                  onChange={handleInputChange}
                  label="Status"
                >
                  <MenuItem value="pendente">Pendente</MenuItem>
                  <MenuItem value="pago">Pago</MenuItem>
                  <MenuItem value="atrasado">Atrasado</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="conta_pagamento"
                label="Conta/Chave PIX de Pagamento"
                fullWidth
                value={formData.conta_pagamento}
                onChange={handleInputChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                name="descricao"
                label="Descrição"
                fullWidth
                multiline
                rows={3}
                value={formData.descricao}
                onChange={handleInputChange}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancelar</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            Salvar
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default ContasPagar;
