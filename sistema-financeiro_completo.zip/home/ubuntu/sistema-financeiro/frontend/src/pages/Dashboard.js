import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Paper, 
  Grid, 
  Card, 
  CardContent, 
  Box,
  Tabs,
  Tab,
  Divider
} from '@mui/material';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';
import axios from 'axios';

const API_URL = 'http://localhost:8000/api';

const Dashboard = () => {
  const [contasReceber, setContasReceber] = useState([]);
  const [contasPagar, setContasPagar] = useState([]);
  const [tabValue, setTabValue] = useState(0);
  const [resumoFinanceiro, setResumoFinanceiro] = useState({
    totalReceber: 0,
    totalPagar: 0,
    saldoProjetado: 0,
    contasAtrasadas: 0,
    contasPendentes: 0
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [receber, pagar] = await Promise.all([
        axios.get(`${API_URL}/contas-receber/`),
        axios.get(`${API_URL}/contas-pagar/`)
      ]);
      
      setContasReceber(receber.data);
      setContasPagar(pagar.data);
      
      // Calcular resumo financeiro
      const totalReceber = receber.data.reduce((acc, conta) => 
        conta.status !== 'recebido' ? acc + conta.valor : acc, 0);
      
      const totalPagar = pagar.data.reduce((acc, conta) => 
        conta.status !== 'pago' ? acc + conta.valor : acc, 0);
      
      const contasAtrasadas = [
        ...receber.data.filter(conta => conta.status === 'atrasado'),
        ...pagar.data.filter(conta => conta.status === 'atrasado')
      ].length;
      
      const contasPendentes = [
        ...receber.data.filter(conta => conta.status === 'pendente'),
        ...pagar.data.filter(conta => conta.status === 'pendente')
      ].length;
      
      setResumoFinanceiro({
        totalReceber,
        totalPagar,
        saldoProjetado: totalReceber - totalPagar,
        contasAtrasadas,
        contasPendentes
      });
      
    } catch (error) {
      console.error('Erro ao buscar dados:', error);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Dados para o gráfico de fluxo de caixa
  const prepareFluxoCaixaData = () => {
    const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const data = meses.map(mes => ({
      name: mes,
      receber: 0,
      pagar: 0
    }));
    
    // Agrupar contas a receber por mês
    contasReceber.forEach(conta => {
      const data = new Date(conta.data_prevista);
      const mes = data.getMonth();
      data[mes].receber += conta.valor;
    });
    
    // Agrupar contas a pagar por mês
    contasPagar.forEach(conta => {
      const data = new Date(conta.data_vencimento);
      const mes = data.getMonth();
      data[mes].pagar += conta.valor;
    });
    
    return data;
  };

  // Dados para o gráfico de status
  const prepareStatusData = () => {
    const statusReceber = {
      pendente: contasReceber.filter(c => c.status === 'pendente').length,
      recebido: contasReceber.filter(c => c.status === 'recebido').length,
      atrasado: contasReceber.filter(c => c.status === 'atrasado').length
    };
    
    const statusPagar = {
      pendente: contasPagar.filter(c => c.status === 'pendente').length,
      pago: contasPagar.filter(c => c.status === 'pago').length,
      atrasado: contasPagar.filter(c => c.status === 'atrasado').length
    };
    
    return [
      { name: 'Pendente', receber: statusReceber.pendente, pagar: statusPagar.pendente },
      { name: 'Concluído', receber: statusReceber.recebido, pagar: statusPagar.pago },
      { name: 'Atrasado', receber: statusReceber.atrasado, pagar: statusPagar.atrasado }
    ];
  };

  // Dados para o gráfico de pizza
  const preparePieData = () => {
    return [
      { name: 'A Receber', value: resumoFinanceiro.totalReceber },
      { name: 'A Pagar', value: resumoFinanceiro.totalPagar }
    ];
  };

  const COLORS = ['#4caf50', '#f44336'];

  return (
    <>
      <Typography variant="h5" component="h1" gutterBottom>
        Dashboard Financeiro
      </Typography>

      <Grid container spacing={3}>
        {/* Cards de resumo */}
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total a Receber
              </Typography>
              <Typography variant="h5" component="div" color="primary">
                {formatCurrency(resumoFinanceiro.totalReceber)}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total a Pagar
              </Typography>
              <Typography variant="h5" component="div" color="error">
                {formatCurrency(resumoFinanceiro.totalPagar)}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Saldo Projetado
              </Typography>
              <Typography 
                variant="h5" 
                component="div" 
                color={resumoFinanceiro.saldoProjetado >= 0 ? 'primary' : 'error'}
              >
                {formatCurrency(resumoFinanceiro.saldoProjetado)}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Contas Pendentes/Atrasadas
              </Typography>
              <Typography variant="h5" component="div">
                {resumoFinanceiro.contasPendentes} / {resumoFinanceiro.contasAtrasadas}
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* Gráficos */}
        <Grid item xs={12}>
          <Paper sx={{ p: 2 }}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
              <Tabs value={tabValue} onChange={handleTabChange} aria-label="gráficos financeiros">
                <Tab label="Fluxo de Caixa" />
                <Tab label="Status das Contas" />
                <Tab label="Distribuição" />
              </Tabs>
            </Box>
            
            {/* Gráfico de Fluxo de Caixa */}
            {tabValue === 0 && (
              <Box sx={{ height: 400 }}>
                <Typography variant="h6" gutterBottom>
                  Fluxo de Caixa Mensal
                </Typography>
                <ResponsiveContainer width="100%" height="90%">
                  <BarChart
                    data={prepareFluxoCaixaData()}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => formatCurrency(value)} />
                    <Legend />
                    <Bar dataKey="receber" name="A Receber" fill="#4caf50" />
                    <Bar dataKey="pagar" name="A Pagar" fill="#f44336" />
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            )}
            
            {/* Gráfico de Status */}
            {tabValue === 1 && (
              <Box sx={{ height: 400 }}>
                <Typography variant="h6" gutterBottom>
                  Status das Contas
                </Typography>
                <ResponsiveContainer width="100%" height="90%">
                  <BarChart
                    data={prepareStatusData()}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="receber" name="Contas a Receber" fill="#4caf50" />
                    <Bar dataKey="pagar" name="Contas a Pagar" fill="#f44336" />
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            )}
            
            {/* Gráfico de Pizza */}
            {tabValue === 2 && (
              <Box sx={{ height: 400 }}>
                <Typography variant="h6" gutterBottom>
                  Distribuição Financeira
                </Typography>
                <ResponsiveContainer width="100%" height="90%">
                  <PieChart>
                    <Pie
                      data={preparePieData()}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={150}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {preparePieData().map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => formatCurrency(value)} />
                  </PieChart>
                </ResponsiveContainer>
              </Box>
            )}
          </Paper>
        </Grid>
      </Grid>
    </>
  );
};

export default Dashboard;
