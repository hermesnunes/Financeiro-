import React, { useState } from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
import axios from 'axios';
import { Container, Box, TextField, Button, Typography, Link, Alert } from '@mui/material';
import { API_BASE_URL } from '../index'; // Import API base URL

function RegisterPage() {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState(''); // Optional email field
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const navigate = useNavigate();

    const handleRegister = async (event) => {
        event.preventDefault();
        setError('');
        setSuccess('');

        if (password !== confirmPassword) {
            setError('As senhas não coincidem.');
            return;
        }

        try {
            const response = await axios.post(`${API_BASE_URL}/register`, {
                username: username,
                email: email, // Send email if collected
                password: password,
            });

            if (response.status === 201) {
                setSuccess('Usuário registrado com sucesso! Você será redirecionado para o login.');
                // Optionally auto-login or redirect to login page after a delay
                setTimeout(() => {
                    navigate('/login');
                }, 3000); // Redirect after 3 seconds
            } else {
                setError('Falha no registro. Resposta inesperada do servidor.');
            }
        } catch (err) {
            if (err.response && err.response.data && err.response.data.detail) {
                setError(`Erro no registro: ${err.response.data.detail}`);
            } else {
                setError('Erro ao tentar registrar. Tente novamente mais tarde.');
                console.error("Registration error:", err);
            }
        }
    };

    return (
        <Container component="main" maxWidth="xs">
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}
            >
                <Typography component="h1" variant="h5">
                    Registrar Novo Usuário
                </Typography>
                <Box component="form" onSubmit={handleRegister} noValidate sx={{ mt: 1 }}>
                    {error && <Alert severity="error" sx={{ width: '100%', mt: 2, mb: 1 }}>{error}</Alert>}
                    {success && <Alert severity="success" sx={{ width: '100%', mt: 2, mb: 1 }}>{success}</Alert>}
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        id="username"
                        label="Nome de Usuário"
                        name="username"
                        autoComplete="username"
                        autoFocus
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                    <TextField
                        margin="normal"
                        fullWidth // Make email optional on backend if desired
                        id="email"
                        label="Email (Opcional)"
                        name="email"
                        autoComplete="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        name="password"
                        label="Senha"
                        type="password"
                        id="password"
                        autoComplete="new-password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        name="confirmPassword"
                        label="Confirmar Senha"
                        type="password"
                        id="confirmPassword"
                        autoComplete="new-password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        sx={{ mt: 3, mb: 2 }}
                        disabled={!!success} // Disable button after success
                    >
                        Registrar
                    </Button>
                    <Box textAlign="center">
                        <Link component={RouterLink} to="/login" variant="body2">
                            {"Já tem uma conta? Faça login"}
                        </Link>
                    </Box>
                </Box>
            </Box>
        </Container>
    );
}

export default RegisterPage;

