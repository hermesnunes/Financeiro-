import React, { useState } from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
import axios from 'axios';
import { Container, Box, TextField, Button, Typography, Link, Alert } from '@mui/material';
import { API_BASE_URL } from '../index'; // Import API base URL

function LoginPage() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (event) => {
        event.preventDefault();
        setError(''); // Clear previous errors

        const formData = new URLSearchParams();
        formData.append('username', username);
        formData.append('password', password);

        try {
            const response = await axios.post(`${API_BASE_URL}/token`, formData, {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            });

            if (response.data.access_token) {
                localStorage.setItem('accessToken', response.data.access_token);
                axios.defaults.headers.common['Authorization'] = `Bearer ${response.data.access_token}`;
                navigate('/'); // Redirect to dashboard or home page after login
            } else {
                setError('Falha no login. Token não recebido.');
            }
        } catch (err) {
            if (err.response && err.response.status === 401) {
                setError('Nome de usuário ou senha incorretos.');
            } else if (err.response && err.response.data && err.response.data.detail) {
                 setError(`Erro: ${err.response.data.detail}`);
            } else {
                setError('Erro ao tentar fazer login. Tente novamente mais tarde.');
                console.error("Login error:", err);
            }
        }
    };

    return (
        <Container component="main" maxWidth="xs">
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}
            >
                <Typography component="h1" variant="h5">
                    Login
                </Typography>
                <Box component="form" onSubmit={handleLogin} noValidate sx={{ mt: 1 }}>
                    {error && <Alert severity="error" sx={{ width: '100%', mt: 2, mb: 1 }}>{error}</Alert>}
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        id="username"
                        label="Nome de Usuário"
                        name="username"
                        autoComplete="username"
                        autoFocus
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        name="password"
                        label="Senha"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    {/* Add Checkbox for 'Remember me' if needed */}
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        sx={{ mt: 3, mb: 2 }}
                    >
                        Entrar
                    </Button>
                    <Box textAlign="center">
                        <Link component={RouterLink} to="/register" variant="body2">
                            {"Não tem uma conta? Registre-se"}
                        </Link>
                    </Box>
                </Box>
            </Box>
        </Container>
    );
}

export default LoginPage;

